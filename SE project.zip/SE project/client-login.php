<?php
session_start();
include "connection.php"; // Ensure this file correctly sets `$conn`

class ClientAuth {
    private $conn;
    private $table = "clients"; // Ensure this table exists in your database

    public function __construct($db) {
        if (!$db) {
            die("❌ Database connection is missing.");
        }
        $this->conn = $db;
    }

    // Register a new client and log them in
    public function register($email, $password) {
        if (empty($email) || empty($password)) {
            return "⚠️ Email and password are required!";
        }

        // Check if the email already exists
        $sql_check = "SELECT id FROM $this->table WHERE email = ?";
        $stmt_check = $this->conn->prepare($sql_check);
        $stmt_check->bind_param("s", $email);
        $stmt_check->execute();
        $stmt_check->store_result();

        if ($stmt_check->num_rows > 0) {
            return "⚠️ Email already registered!";
        }

        // ❌ **No Hashing Applied (Insecure)** ❌
        $sql = "INSERT INTO $this->table (email, password) VALUES (?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ss", $email, $password); // Storing password as plain text

        if ($stmt->execute()) {
            // Log the user in immediately after registration
            $user_id = $this->conn->insert_id; // Get the ID of the newly inserted row
            $_SESSION["client_id"] = $user_id;
            $_SESSION["email"] = $email;
            return "✅ Registration successful!";
        } else {
            return "❌ Registration failed: " . $stmt->error;
        }
    }
}

// Ensure `$conn` is available before passing it
if (!isset($conn)) {
    die("❌ Database connection is missing.");
}

// Initialize authentication class
$auth = new ClientAuth($conn);

// Handle registration request
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize input
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $password = $_POST['password']; // Password is stored as plain text

    // Check if email and password are provided
    if (empty($email) || empty($password)) {
        echo "<script>alert('⚠️ Email and password are required!'); window.location.href='client-register.html';</script>";
        exit();
    }

    // Attempt to register the client
    $register_result = $auth->register($email, $password);
    if ($register_result === "✅ Registration successful!") {
        echo "<script>alert('$register_result'); window.location.href='home.html';</script>";
    } else {
        echo "<script>alert('$register_result'); window.location.href='client-register.html';</script>";
    }
}
?>
