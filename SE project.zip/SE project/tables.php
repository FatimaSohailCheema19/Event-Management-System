<?php
// Include the database configuration file
require_once 'connection.php';

// Create a MySQLi connection
$database = new Database();
$conn = $database->getConnection(); // Now $conn is MySQLi

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Table creation queries
$tables = [
    "CREATE TABLE IF NOT EXISTS clients (
        id INT AUTO_INCREMENT PRIMARY KEY,
        password VARCHAR(255) NOT NULL,
        email VARCHAR(100) NOT NULL UNIQUE
    )",
    "CREATE TABLE IF NOT EXISTS planners (
        id INT AUTO_INCREMENT PRIMARY KEY,
        password VARCHAR(255) NOT NULL,
        email VARCHAR(100) NOT NULL UNIQUE
    )",
    "CREATE TABLE IF NOT EXISTS events (
        id INT AUTO_INCREMENT PRIMARY KEY,
        event_name VARCHAR(100) NOT NULL,
        event_time TIME NOT NULL,
        location VARCHAR(255) NOT NULL,
        attendees INT NOT NULL,
        decor_type VARCHAR(100),
        other_details TEXT,
        confirmed TINYINT(1) DEFAULT 0
    )",
    "CREATE TABLE IF NOT EXISTS planner_events (
        id INT AUTO_INCREMENT PRIMARY KEY,
        client_name VARCHAR(255) NOT NULL,
        event_date DATE NOT NULL,
        event_month YEAR NOT NULL,
        event_time TIME NOT NULL,
        location VARCHAR(255) NOT NULL,
        number_of_guests INT NOT NULL CHECK (number_of_guests > 0),
        decor VARCHAR(255),
        special_requirements TEXT,
        confirmed TINYINT(1) DEFAULT 0,
        CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    "CREATE TABLE IF NOT EXISTS reservation (
        id INT AUTO_INCREMENT PRIMARY KEY,
        event_name VARCHAR(255) NOT NULL,
        event_time TIME NOT NULL,
        location VARCHAR(255) NOT NULL,
        confirmed TINYINT(1) DEFAULT 0
    )",
    "CREATE TABLE IF NOT EXISTS tasks (
        id INT AUTO_INCREMENT PRIMARY KEY,
        event_id INT NOT NULL,
        task_name VARCHAR(100) NOT NULL,
        task_description TEXT,
        assigned_to VARCHAR(100),
        start_time DATETIME NOT NULL,
        end_time DATETIME NOT NULL,
        FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE
    )",
    "CREATE TABLE IF NOT EXISTS task_progress (
        ProgressID INT AUTO_INCREMENT PRIMARY KEY,
        TaskID INT NOT NULL,
        TaskProgress ENUM('Not Started', 'In Progress', 'Completed') NOT NULL,
        UpdatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (TaskID) REFERENCES tasks(id) ON DELETE CASCADE
    )",
    "CREATE TABLE IF NOT EXISTS contacts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL,
        message TEXT NOT NULL
    )",
    "CREATE TABLE IF NOT EXISTS Budget (
        BudgetID INT AUTO_INCREMENT PRIMARY KEY,
        EventID INT NOT NULL,
        TotalBudget DECIMAL(10,2) NOT NULL,
        BudgetUsed DECIMAL(10,2) NOT NULL,
        CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UpdatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (EventID) REFERENCES events(id) ON DELETE CASCADE
    )"
];

// Loop through tables and execute queries using MySQLi
foreach ($tables as $query) {
    if (mysqli_query($conn, $query)) {
        echo "✅ Table checked/created successfully.<br>";
    } else {
        echo "❌ Error creating table: " . mysqli_error($conn) . "<br>";
    }
}

// Close connection
mysqli_close($conn);
?>
