<?php
session_start();
include "connection.php"; // Ensure this file correctly sets `$conn`

class EventService {
    private $conn;

    public function __construct($db) {
        if (!$db) {
            die("❌ Database connection is missing.");
        }
        $this->conn = $db;
    }

    public function saveEvent($eventName, $eventTime, $location, $attendees, $decorType, $otherDetails) {
        // Sanitize and validate inputs
        $eventName = trim($this->conn->real_escape_string($eventName));
        $eventTime = trim($eventTime);
        $location = trim($this->conn->real_escape_string($location));
        $decorType = trim($this->conn->real_escape_string($decorType));
        $otherDetails = trim($this->conn->real_escape_string($otherDetails));

        // Validate attendees (should be a positive integer)
        if (!is_numeric($attendees) || intval($attendees) <= 0) {
            return "❌ Invalid attendees value.";
        }
        $attendees = intval($attendees); // Ensure it's an integer

        // Prepare and execute the SQL query
        $sql = "INSERT INTO events (event_name, event_time, location, attendees, decor_type, other_details, confirmed) VALUES (?, ?, ?, ?, ?, ?, 0)";
        $stmt = $this->conn->prepare($sql);

        if (!$stmt) {
            return "❌ Error preparing statement: " . $this->conn->error;
        }

        $stmt->bind_param("sssiis", $eventName, $eventTime, $location, $attendees, $decorType, $otherDetails);

        if ($stmt->execute()) {
            $eventId = $stmt->insert_id;
            $stmt->close();
            return $eventId; // Return the last inserted event ID
        } else {
            $stmtError = $stmt->error;
            $stmt->close();
            return "❌ Error saving event: " . $stmtError;
        }
    }
}

// Ensure `$conn` is available before passing it
if (!isset($conn)) {
    die("❌ Database connection is missing.");
}

$eventService = new EventService($conn);

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['save_event'])) {
    // Debug: Print POST data
    echo "<pre>";
    print_r($_POST);
    echo "</pre>";

    // Ensure all form fields are set
    $eventName = $_POST['event_name'] ?? "";
$eventTime = $_POST['event_time'] ?? "";
$location = $_POST['location'] ?? "";
$attendees = $_POST['attendees'] ?? "";
$decorType = $_POST['decor_type'] ?? "";
$otherDetails = $_POST['other_details'] ?? "";

// Ensure no empty required fields
if (empty($eventName) || empty($eventTime) || empty($location) || empty($attendees)) {
    echo "<script>alert('⚠️ Please fill in all required fields.'); window.location.href='services.html';</script>";
    exit();
}

$result = $eventService->saveEvent($eventName, $eventTime, $location, $attendees, $decorType, $otherDetails);

if (is_numeric($result)) {
    session_start();  // Ensure session is started before using $_SESSION
    $_SESSION['event_id'] = $result; // Store event ID in session
    
    // Corrected redirection
    header("Location: confirm_reservation.php");
    exit();
} else {
    echo "<script>alert('$result'); window.location.href='services.html';</script>";
    exit();
}
}
?>