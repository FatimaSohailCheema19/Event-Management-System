<?php
session_start();
include "connection.php"; // Ensure this file correctly sets `$conn`

class TaskProgress {
    private $conn;

    public function __construct($db) {
        if (!$db) {
            die("❌ Database connection is missing.");
        }
        $this->conn = $db;
    }

    public function saveTaskProgress($taskName, $taskProgress) {
        // Sanitize and validate inputs
        $taskName = trim($this->conn->real_escape_string($taskName));
        $taskProgress = trim($this->conn->real_escape_string($taskProgress));

        // Prepare and execute the SQL query
        $sql = "INSERT INTO task_progress (task_name, progress_status) VALUES (?, ?)";
        $stmt = $this->conn->prepare($sql);

        if (!$stmt) {
            return "❌ Error preparing statement: " . $this->conn->error;
        }

        $stmt->bind_param("ss", $taskName, $taskProgress);

        if ($stmt->execute()) {
            $stmt->close();
            return "✅ Task progress saved successfully!";
        } else {
            $stmt->close();
            return "❌ Error saving task progress: " . $stmt->error;
        }
    }
}

// Ensure `$conn` is available before passing it
if (!isset($conn)) {
    die("❌ Database connection is missing.");
}

$taskProgress = new TaskProgress($conn);

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Debug: Print POST data
    echo "<pre>";
    print_r($_POST);
    echo "</pre>";

    // Ensure all form fields are set
    $taskName = $_POST['task_name'] ?? "";
    $taskProgressStatus = $_POST['task_progress'] ?? "";

    // Ensure no empty required fields
    if (empty($taskName) || empty($taskProgressStatus)) {
        echo "<script>alert('⚠️ Please fill in all required fields.'); window.location.href='track_progress.html';</script>";
        exit();
    }

    $result = $taskProgress->saveTaskProgress($taskName, $taskProgressStatus);

    if ($result === "✅ Task progress saved successfully!") {
        echo "<script>alert('$result'); window.location.href='index.html';</script>";
    } else {
        echo "<script>alert('$result'); window.location.href='track_progress.html';</script>";
    }
}
?>