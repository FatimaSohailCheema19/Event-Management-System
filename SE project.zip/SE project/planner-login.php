<?php
session_start();
include "connection.php"; // Ensure database connection is established

// Function to handle login and registration
class PlannerAuth {
    private $conn;
    private $table = "planners";

    public function __construct($db) {
        if (!$db) {
            die("❌ Database connection failed.");
        }
        $this->conn = $db;
    }

    // Function to check if user exists and log in
    public function login($email, $password) {
        $sql = "SELECT id, email, password FROM $this->table LIMIT 1"; // Only fetch the first planner
        $stmt = $this->conn->prepare($sql);
        if (!$stmt) {
            die("Query preparation failed: " . $this->conn->error);
        }
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {
            // ✅ Directly compare the plain text password
            if ($email === $row['email'] && $password === $row['password']) { 
                $_SESSION['planner_id'] = $row['id'];
                $_SESSION['planner_email'] = $row['email'];
                return "login_success";
            } else {
                return "invalid_credentials";
            }
        }
        return "no_planner";
    }

    // Function to register a planner (Only one allowed)
    public function register($email, $password) {
        // Check if a planner already exists
        $check_sql = "SELECT id FROM $this->table LIMIT 1";
        $check_stmt = $this->conn->prepare($check_sql);
        if (!$check_stmt) {
            die("Query preparation failed: " . $this->conn->error);
        }
        $check_stmt->execute();
        $check_stmt->store_result();

        if ($check_stmt->num_rows > 0) {
            return "planner_exists"; // Stop registration if a planner is already in the system
        }

        // Store password without hashing (Not recommended)
        $sql = "INSERT INTO $this->table (email, password) VALUES (?, ?)";
        $stmt = $this->conn->prepare($sql);
        if (!$stmt) {
            die("Query preparation failed: " . $this->conn->error);
        }
        $stmt->bind_param("ss", $email, $password);
        
        if ($stmt->execute()) {
            $_SESSION['planner_id'] = $stmt->insert_id; // Get newly inserted ID
            $_SESSION['planner_email'] = $email;
            return "registration_success";
        } else {
            return "registration_failed: " . $stmt->error;
        }
    }
}

// Ensure connection is available
if (!isset($conn)) {
    die("❌ Database connection is missing.");
}

// Handle login request
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if (empty($email) || empty($password)) {
        echo "<script>alert('⚠️ Email and password are required!'); window.location.href='planner-login.html';</script>";
        exit();
    }

    $plannerAuth = new PlannerAuth($conn);
    $login_status = $plannerAuth->login($email, $password);

    if ($login_status === "login_success") {
        echo "<script>alert('✅ Login successful!'); window.location.href='indexp.html';</script>";
    } elseif ($login_status === "invalid_credentials") {
        echo "<script>alert('❌ Incorrect email or password!'); window.location.href='planner-login.html';</script>";
    } elseif ($login_status === "no_planner") {
        // If no planner exists, attempt registration
        $register_status = $plannerAuth->register($email, $password);
        if ($register_status === "registration_success") {
            echo "<script>alert('✅ Registration successful! Logging in...'); window.location.href='indexp.html';</script>";
        } elseif ($register_status === "planner_exists") {
            echo "<script>alert('⚠️ A planner already exists. Only one planner is allowed!'); window.location.href='planner-login.html';</script>";
        } else {
            echo "<script>alert('❌ Registration failed: $register_status'); window.location.href='planner-login.html';</script>";
        }
    }
}
?>
