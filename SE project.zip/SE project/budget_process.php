<?php
session_start();
include "connection.php"; // Ensure database connection

// Debugging: Check if connection is working
if (!$conn) {
    die("❌ Database connection error: " . mysqli_connect_error());
}

// Fetch events from planner_events table (only the id)
$eventOptions = "";
$sql = "SELECT id FROM planner_events"; // Fetch only the id column
$result = $conn->query($sql);

if (!$result) {
    die("❌ SQL Error: " . $conn->error);
}

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $eventOptions .= "<option value='{$row['id']}'>Event ID: {$row['id']}</option>"; // Display only the Event ID
    }
} else {
    $eventOptions = "<option value=''>No events available</option>"; // Handle empty events
}

// Define the Budget class
class Budget {
    private $conn;
    private $eventId;
    private $totalBudget;
    private $budgetUsed;

    public function __construct($db, $eventId, $totalBudget, $budgetUsed) {
        if (!$db) {
            die("❌ Database connection is missing.");
        }
        $this->conn = $db;

        // Validate inputs
        $this->eventId = filter_var(trim($eventId), FILTER_VALIDATE_INT);
        $this->totalBudget = is_numeric($totalBudget) ? floatval($totalBudget) : false;
        $this->budgetUsed = is_numeric($budgetUsed) ? floatval($budgetUsed) : false;
    }

    private function validateInputs() {
        if (!$this->eventId || !$this->totalBudget || !$this->budgetUsed) {
            return "⚠️ All fields are required and must be valid numbers.";
        }
        if ($this->budgetUsed > $this->totalBudget) {
            return "⚠️ Budget used cannot exceed total budget.";
        }

        // Check if EventID exists in planner_events
        $sql = "SELECT 1 FROM planner_events WHERE id = ?"; // Check by id column
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $this->eventId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            return "⚠️ Invalid Event ID. The event does not exist.";
        }
        return true;
    }

    public function saveBudget() {
        $validation = $this->validateInputs();
        if ($validation !== true) {
            return $validation;
        }

        // Ensure Budget table has EventID column
        $sql = "INSERT INTO Budget (EventID, TotalBudget, BudgetUsed) 
                VALUES (?, ?, ?) 
                ON DUPLICATE KEY UPDATE TotalBudget = ?, BudgetUsed = ?";
        $stmt = $this->conn->prepare($sql);

        if (!$stmt) {
            return "❌ SQL Error: " . $this->conn->error;
        }

        $stmt->bind_param("idddd", $this->eventId, $this->totalBudget, $this->budgetUsed, $this->totalBudget, $this->budgetUsed);
        
        if ($stmt->execute()) {
            $stmt->close();
            return true;
        } else {
            $stmtError = $stmt->error;
            $stmt->close();
            return "❌ Error saving budget: " . $stmtError;
        }
    }
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $eventId = $_POST['event_id'] ?? "";
    $totalBudget = $_POST['total_budget'] ?? "";
    $budgetUsed = $_POST['budget_used'] ?? "";

    $budget = new Budget($conn, $eventId, $totalBudget, $budgetUsed);
    $result = $budget->saveBudget();

    if ($result === true) {
        echo "<script>alert('✅ Budget saved successfully!'); window.location.href='budget_list.php';</script>";
    } else {
        echo "<script>alert('$result'); window.location.href='budget_manage.php';</script>";
    }
}
?>
