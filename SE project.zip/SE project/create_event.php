<?php
session_start();
include "connection.php"; // Ensure this file correctly sets `$conn`

class PlannerEvent {
    private $conn;

    public function __construct($db) {
        if (!$db) {
            die("❌ Database connection is missing.");
        }
        $this->conn = $db;
    }

    public function saveEvent($clientName, $eventDate, $eventTime, $location, $guestCount, $decor, $specialRequirements) {
        // Sanitize inputs
        $clientName = trim($this->conn->real_escape_string($clientName));
        $eventDate = trim($eventDate);
        $eventTime = trim($eventTime);
        $location = trim($this->conn->real_escape_string($location));
        $decor = trim($this->conn->real_escape_string($decor));
        $specialRequirements = trim($this->conn->real_escape_string($specialRequirements));

        // Validate guest count (should be a positive integer)
        if (!is_numeric($guestCount) || intval($guestCount) <= 0) {
            return "❌ Invalid guest count.";
        }
        $guestCount = intval($guestCount); // Ensure it's an integer

        // Prepare and execute the SQL query
        $sql = "INSERT INTO planner_events (client_name, event_date, event_time, location, number_of_guests, decor, special_requirements, confirmed) 
                VALUES (?, ?, ?, ?, ?, ?, ?, 0)";
        $stmt = $this->conn->prepare($sql);

        if (!$stmt) {
            return "❌ Error preparing statement: " . $this->conn->error;
        }

        $stmt->bind_param("sssiiss", $clientName, $eventDate, $eventTime, $location, $guestCount, $decor, $specialRequirements);

        if ($stmt->execute()) {
            $eventId = $stmt->insert_id;
            $stmt->close();
            return $eventId; // Return the last inserted event ID
        } else {
            $stmtError = $stmt->error;
            $stmt->close();
            return "❌ Error saving event: " . $stmtError;
        }
    }
}

// Ensure `$conn` is available before passing it
if (!isset($conn)) {
    die("❌ Database connection is missing.");
}

$eventService = new PlannerEvent($conn);

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Debug: Print POST data
    echo "<pre>";
    print_r($_POST);
    echo "</pre>";

    // Ensure all form fields are set
    $clientName = $_POST['client_name'] ?? "";
    $eventDate = $_POST['event_date'] ?? "";
    $eventTime = $_POST['event_time'] ?? "";
    $location = $_POST['location'] ?? "";
    $guestCount = $_POST['guest_count'] ?? "";
    $decor = $_POST['decor'] ?? "";
    $specialRequirements = $_POST['special_requirements'] ?? "";

    // Ensure no empty required fields
    if (empty($clientName) || empty($eventDate) || empty($eventTime) || empty($location) || empty($guestCount)) {
        echo "<script>alert('⚠️ Please fill in all required fields.'); window.location.href='create_event.php';</script>";
        exit();
    }

    $result = $eventService->saveEvent($clientName, $eventDate, $eventTime, $location, $guestCount, $decor, $specialRequirements);

    if (is_numeric($result)) {
        session_start(); // Ensure session is started before using $_SESSION
        $_SESSION['event_id'] = $result; // Store event ID in session
        
        // Corrected redirection
        header("Location: confirm_reservation.php");
        exit();
    } else {
        echo "<script>alert('$result'); window.location.href='create_event.php';</script>";
        exit();
    }
}
?>
