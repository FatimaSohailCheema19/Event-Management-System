<?php
require_once 'connection.php';
$database = new Database();
$conn = $database->getConnection();
?>