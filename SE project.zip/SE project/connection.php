<?php
class Database {
    private $servername = "localhost";
    private $username = "root";
    private $password = ""; // Change if needed
    private $dbname = "eventmanagementsystem"; 
    public $conn;

    // Constructor initializes the connection automatically
    public function __construct() {
        $this->conn = new mysqli($this->servername, $this->username, $this->password);

        // Check connection
        if ($this->conn->connect_error) {
            die("❌ Connection failed: " . $this->conn->connect_error);
        }

        // Create database if it doesn't exist
        $sql = "CREATE DATABASE IF NOT EXISTS " . $this->dbname;
        if ($this->conn->query($sql) === FALSE) {
            die("❌ Error creating database: " . $this->conn->error);
        }

        // Select the database
        $this->conn->select_db($this->dbname);

        // Uncomment for debugging
        // echo "✅ Database connection successful!";
    }

    // Function to get the connection object
    public function getConnection() {
        return $this->conn;
    }
}

// Create a global database instance
$database = new Database();
$conn = $database->getConnection();

// Define constants for database credentials
define("DB_HOST", "localhost");
define("DB_USER", "root"); 
define("DB_PASS", "");
define("DB_NAME", "eventmanagementsystem"); 
?>
