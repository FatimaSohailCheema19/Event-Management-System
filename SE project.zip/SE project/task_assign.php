<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assign Task</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #121212;
            color: white;
        }
        .container {
            background: #1f1f1f;
            padding: 30px;
            border-radius: 10px;
            margin-top: 50px;
            box-shadow: 0 0 10px rgba(23, 162, 104, 0.4);
        }
        .form-control {
            background: #252525;
            color: white;
            border: none;
        }
        .form-control::placeholder {
            color: #b0b0b0;
        }
        .form-control:focus {
            background: #252525;
            box-shadow: 0 0 8px #17a45c;
            color: white;
        }
        select.form-control {
            background: #252525;
            color: white;
        }
        .btn-primary {
            background: #117a65;
            border: none;
        }
        .btn-primary:hover {
            background: #0e624f;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-dark bg-dark">
    <div class="container d-flex justify-content-between">
        <a class="navbar-brand" href="#">Event Management</a>
        <a class="navbar-brand" href="indexp.html">Start</a>
    </div>
</nav>
<div class="container">
    <h2 class="mb-4">Assign Task & Set Schedule</h2>
    <form action="task_manager.php" method="POST">
        <div class="mb-3">
            <label class="form-label">Task Name</label>
            <input type="text" name="task_name" class="form-control" placeholder="Enter task name" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Task Description</label>
            <textarea name="task_description" class="form-control" placeholder="Enter task details" required></textarea>
        </div>
        <div class="mb-3">
            <label class="form-label">Assignee Name</label>
            <input type="text" name="assigned_to" class="form-control" placeholder="Enter assignee email" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Start Time</label>
            <input type="datetime-local" name="start_time" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">End Time</label>
            <input type="datetime-local" name="end_time" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Select Event:</label>
            <select name="event_id" class="form-control" required>
                <?php
                include "connection.php";
                $result = $conn->query("SELECT id, event_name FROM events");
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='" . $row['id'] . "'>" . $row['event_name'] . "</option>";
                }
                ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Save</button>
        <a href="index.html" class="btn btn-secondary">Cancel</a>
    </form>
</div>
</body>
</html>
