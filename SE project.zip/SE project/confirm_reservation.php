<?php
session_start();
include "connection.php"; // Ensure this file correctly sets `$conn`

// Check if event ID is set in the session
if (!isset($_SESSION['event_id'])) {
    die("❌ Event ID not found in session.");
}

$eventId = $_SESSION['event_id'];

class EventReservation {
    private $conn;
    private $event_id;

    public function __construct($conn, $event_id) {
        $this->conn = $conn;
        $this->event_id = $event_id;
    }

    public function getEventDetails() {
        $sql = "SELECT id, event_name, event_time, location FROM events WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        if (!$stmt) {
            throw new Exception("Prepare statement failed: " . $this->conn->error);
        }
        $stmt->bind_param("i", $this->event_id);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }

    public function confirmReservation() {
        $eventDetails = $this->getEventDetails();
        if (!$eventDetails) {
            throw new Exception("Event not found.");
        }

        // Start transaction
        $this->conn->begin_transaction();

        try {
            // Insert into reservation table
            $insertSql = "INSERT INTO reservation (event_id, event_name, event_time, location) VALUES (?, ?, ?, ?)";
            $insertStmt = $this->conn->prepare($insertSql);
            if (!$insertStmt) {
                throw new Exception("Prepare statement failed: " . $this->conn->error);
            }
            $insertStmt->bind_param("isss", $this->event_id, $eventDetails['event_name'], $eventDetails['event_time'], $eventDetails['location']);
            $insertStmt->execute();

            if ($insertStmt->affected_rows <= 0) {
                throw new Exception("Failed to insert reservation.");
            }

            // Update events table
            $updateSql = "UPDATE events SET confirmed = 1 WHERE id = ?";
            $updateStmt = $this->conn->prepare($updateSql);
            if (!$updateStmt) {
                throw new Exception("Prepare statement failed: " . $this->conn->error);
            }
            $updateStmt->bind_param("i", $this->event_id);
            $updateStmt->execute();

            if ($updateStmt->affected_rows <= 0) {
                throw new Exception("Failed to update event confirmation status.");
            }

            // Commit transaction
            $this->conn->commit();
            return true;
        } catch (Exception $e) {
            $this->conn->rollback(); // Rollback on error
            throw new Exception("Reservation confirmation failed: " . $e->getMessage());
        }
    }
}

// Fetch event details
try {
    $eventReservation = new EventReservation($conn, $eventId);
    $eventDetails = $eventReservation->getEventDetails();
} catch (Exception $e) {
    die("❌ Error fetching event details: " . $e->getMessage());
}

// Handle reservation confirmation
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['confirm_reservation'])) {
    try {
        if ($eventReservation->confirmReservation()) {
            header("Location: reservation_success.html"); // Redirect to success page
            exit();
        }
    } catch (Exception $e) {
        echo "<script>alert('" . $e->getMessage() . "');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirm Reservation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #1c1c1c;
            color: white;
        }
        .container {
            margin-top: 80px;
        }
        .form-container {
            background: #2c2c2c;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(255, 255, 255, 0.1);
        }
        .btn-custom {
            background-color: #28a745;
            color: white;
        }
        .btn-custom:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="text-center mb-4">Confirm Your Reservation</h2>
        <div class="row">
            <div class="col-md-6 mx-auto">
                <div class="form-container">
                    <h4 class="text-center">Event Details</h4>

                    <?php if ($eventDetails): ?>
                        <p><strong>Event Name:</strong> <?= htmlspecialchars($eventDetails['event_name']) ?></p>
                        <p><strong>Event Time:</strong> <?= htmlspecialchars($eventDetails['event_time']) ?></p>
                        <p><strong>Location:</strong> <?= htmlspecialchars($eventDetails['location']) ?></p>
                        
                        <form action="confirm_reservation.php" method="POST">
                            <input type="hidden" name="event_id" value="<?= $eventId ?>">
                            <button type="submit" name="confirm_reservation" class="btn btn-custom w-100">Confirm Reservation</button>
                        </form>
                    <?php else: ?>
                        <p class="text-danger">❌ Event details not available.</p>
                    <?php endif; ?>
                    
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
