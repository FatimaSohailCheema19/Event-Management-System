<?php
session_start();
include "connection.php"; // Ensure $conn is set

class Task {
    private $conn;
    private $taskName;
    private $taskDescription;
    private $assignedTo;
    private $startTime;
    private $endTime;
    private $eventId;

    // Constructor
    public function __construct($db, $taskName, $taskDescription, $assignedTo, $startTime, $endTime, $eventId) {
        if (!$db) {
            die("❌ Database connection is missing.");
        }
        $this->conn = $db;

        // Trim and assign values
        $this->taskName = trim($taskName);
        $this->taskDescription = trim($taskDescription);
        $this->assignedTo = trim($assignedTo);
        $this->startTime = trim($startTime);
        $this->endTime = trim($endTime);
        $this->eventId = trim($eventId);
    }

    // Validate input fields
    private function validateInputs() {
        if (empty($this->taskName) || empty($this->taskDescription) || empty($this->assignedTo) || empty($this->startTime) || empty($this->endTime) || empty($this->eventId)) {
            return "⚠️ All fields are required.";
        }
    
        // Optional: Check if assigned_to contains only letters and spaces
        if (!preg_match("/^[a-zA-Z\s]+$/", $this->assignedTo)) {
            return "⚠️ Assignee name should only contain letters and spaces.";
        }
    
        if (strtotime($this->startTime) >= strtotime($this->endTime)) {
            return "⚠️ Start time must be before end time.";
        }
    
        // Ensure event_id exists in the events table
        $sql = "SELECT id FROM events WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $this->eventId);
        $stmt->execute();
        $result = $stmt->get_result();
    
        if ($result->num_rows === 0) {
            return "⚠️ Invalid Event ID. The event does not exist.";
        }
    
        return true; // Valid inpu
    }

    // Save task to database
    public function saveTask() {
        $validation = $this->validateInputs();
        if ($validation !== true) {
            return $validation; // Return validation error
        }

        $sql = "INSERT INTO tasks (task_name, task_description, assigned_to, start_time, end_time, event_id) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $this->conn->prepare($sql);

        if (!$stmt) {
            return "❌ Error preparing statement: " . $this->conn->error;
        }

        $stmt->bind_param("sssssi", $this->taskName, $this->taskDescription, $this->assignedTo, $this->startTime, $this->endTime, $this->eventId);

        if ($stmt->execute()) {
            $stmt->close();
            return true; // Success
        } else {
            $stmtError = $stmt->error;
            $stmt->close();
            return "❌ Error saving task: " . $stmtError;
        }
    }
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $taskName = $_POST['task_name'] ?? "";
    $taskDescription = $_POST['task_description'] ?? "";
    $assignedTo = $_POST['assigned_to'] ?? "";
    $startTime = $_POST['start_time'] ?? "";
    $endTime = $_POST['end_time'] ?? "";
    $eventId = $_POST['event_id'] ?? ""; // Ensure event_id is passed from the form

    $task = new Task($conn, $taskName, $taskDescription, $assignedTo, $startTime, $endTime, $eventId);
    $result = $task->saveTask();

    if ($result === true) {
        echo "<script>alert('✅ Task saved successfully!'); window.location.href='tasks_list.php';</script>";
    } else {
        echo "<script>alert('$result'); window.location.href='assign_task.php';</script>";
    }
}
?>
