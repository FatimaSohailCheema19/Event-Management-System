<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Budget</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #121212;
            color: #ffffff;
            font-family: Arial, sans-serif;
        }
        .container {
            background: #1f1f1f;
            padding: 30px;
            border-radius: 10px;
            margin-top: 50px;
            box-shadow: 0 0 10px rgba(23, 162, 104, 0.4);
        }
        .form-label {
            font-size: 18px;
            font-weight: bold;
            color: #17a45c;
        }
        .form-control {
            background: #252525;
            color: #ffffff;
            border: 1px solid #17a45c;
            font-size: 16px;
        }
        .form-control:focus {
            background: #2d2d2d;
            color: #ffffff;
            border-color: #17a45c;
            box-shadow: 0 0 10px #17a45c;
        }
        .btn-primary {
            background: #17a45c;
            border: none;
            font-size: 18px;
            font-weight: bold;
        }
        .btn-primary:hover {
            background: #128a53;
        }
        .btn-secondary {
            font-size: 16px;
            font-weight: bold;
        }
        select {
            appearance: none;
            padding: 10px;
            background: #252525;
            color: #ffffff;
            border: 1px solid #17a45c;
            border-radius: 5px;
            font-size: 16px;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-dark bg-dark">
    <div class="container d-flex justify-content-between">
        <a class="navbar-brand text-success fw-bold" href="#">Event Management</a>
        <a class="navbar-brand text-success fw-bold" href="indexp.html">Start</a>
    </div>
</nav>
<div class="container">
    <h2 class="mb-4 text-success text-center">Manage Budget</h2>
    <form action="budget_manage.php" method="POST">
        <div class="mb-3">
            <label class="form-label">Event</label>
            <select name="event_id" id="event_id" required class="form-control">
                <option value="">Select an Event</option>
                <?= $eventOptions; ?>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label">Total Budget</label>
            <input type="number" class="form-control" name="total_budget" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Budget Used</label>
            <input type="number" class="form-control" name="budget_used" required>
        </div>
        <button type="submit" class="btn btn-primary w-100">Save</button>
        <a href="index.html" class="btn btn-secondary w-100 mt-2">Cancel</a>
    </form>
</div>
</body>
</html>
